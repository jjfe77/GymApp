<?php
header('Content-Type: application/json');
include 'conexion.php';

$ventaID = $_GET['VentaID'];

$sql = "SELECT p.Nombre AS Producto, dv.Cantidad, dv.PrecioUnitario, (dv.Cantidad * dv.PrecioUnitario) AS Subtotal
        FROM DetalleVenta dv
        INNER JOIN Productos p ON dv.ProductoID = p.ProductoID
        WHERE dv.VentaID = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $ventaID);
$stmt->execute();
$result = $stmt->get_result();

$detalle = array();
while ($row = $result->fetch_assoc()) {
    $detalle[] = array(
        "Producto"     => strval($row["Producto"]),
        "Cantidad"     => strval($row["Cantidad"]),
        "PrecioUnitario" => strval($row["PrecioUnitario"]),
        "Subtotal"     => strval($row["Subtotal"])
    );
}

echo json_encode($detalle);
$mysqli->close();
?>