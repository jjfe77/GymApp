<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "conexion.php";

// Validar parámetro
if (!isset($_GET['id_alumno']) || !is_numeric($_GET['id_alumno'])) {
    echo json_encode(["error" => "Parámetro id_alumno inválido"]);
    exit;
}

$idAlumno = intval($_GET['id_alumno']);

// Consulta directa a la tabla ejercicios_progreso
$sql = "SELECT 
            fecha,
            nombre_ejercicio AS ejercicio,
            series_plan,
            series_real,
            repes_plan,
            repeticiones_real AS repes_real,
            carga_plan,
            carga_real
        FROM ejercicios_progreso
        WHERE id_alumno = ?
        ORDER BY fecha ASC";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $idAlumno);
$stmt->execute();
$result = $stmt->get_result();

$progresos = [];
while ($row = $result->fetch_assoc()) {
    $progresos[] = $row;
}

echo json_encode($progresos);

$stmt->close();
$mysqli->close();
?>
