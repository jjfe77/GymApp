<?php
header("Content-Type: application/json");
require_once "conexion.php"; // tu archivo de conexión

$id_ejercicio = $_POST['id_ejercicio'] ?? 0;

if ($id_ejercicio == 0) {
    echo json_encode(["status" => "error", "message" => "ID inválido"]);
    exit;
}

$stmt = $mysqli->prepare("DELETE FROM Ejercicios WHERE id_ejercicio = ?");
$stmt->bind_param("i", $id_ejercicio);

if ($stmt->execute()) {
    echo json_encode(["status" => "ok", "message" => "Ejercicio eliminado"]);
} else {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>