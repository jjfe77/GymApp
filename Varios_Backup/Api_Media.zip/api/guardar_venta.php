<?php
/*
header('Content-Type: application/json');
include 'conexion.php';

// Recibir datos del POST
$clienteID   = $_POST['ClienteID'] ?? null;
$fechaVenta  = $_POST['FechaVenta'] ?? null;
$total       = $_POST['Total'] ?? null;
$detalleJson = $_POST['Detalle'] ?? null;

// Validar datos mínimos
if (!$clienteID || !$fechaVenta || !$total || !$detalleJson) {
    echo json_encode(["status" => "error", "message" => "Datos incompletos"]);
    exit;
}

// Decodificar detalle
$detalle = json_decode($detalleJson, true);
if (!$detalle) {
    echo json_encode(["status" => "error", "message" => "Detalle inválido"]);
    exit;
}

$mysqli->begin_transaction();

try {
    // Insertar venta
    $stmtVenta = $mysqli->prepare("INSERT INTO Ventas (ClienteID, FechaVenta, Total) VALUES (?, ?, ?)");
    $stmtVenta->bind_param("isd", $clienteID, $fechaVenta, $total);
    $stmtVenta->execute();
    $ventaID = $stmtVenta->insert_id;

    // Insertar detalle
    $stmtDetalle = $mysqli->prepare("INSERT INTO DetalleVenta (VentaID, ProductoID, Cantidad, PrecioUnitario) VALUES (?, ?, ?, ?)");
    foreach ($detalle as $item) {
        $productoID    = intval($item['ProductoID']);
        $cantidad      = intval($item['Cantidad']);
        $precioUnitario = floatval($item['PrecioUnitario']);

        $stmtDetalle->bind_param("iiid", $ventaID, $productoID, $cantidad, $precioUnitario);
        $stmtDetalle->execute();
    }

    $mysqli->commit();

    echo json_encode([
        "status"  => "ok",
        "ventaID" => $ventaID,
        "message" => "Venta guardada correctamente"
    ]);
} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode([
        "status"  => "error",
        "message" => $e->getMessage()
    ]);
}

$mysqli->close();
*/


header('Content-Type: application/json');
include 'conexion.php';

// Recibir datos del POST
$clienteID   = $_POST['ClienteID'] ?? null;
$fechaVenta  = $_POST['FechaVenta'] ?? null;
$total       = $_POST['Total'] ?? null;
$detalleJson = $_POST['Detalle'] ?? null;

// Validar datos mínimos
if (!$clienteID || !$fechaVenta || !$total || !$detalleJson) {
    echo json_encode(["status" => "error", "message" => "Datos incompletos"]);
    exit;
}

// Decodificar detalle
$detalle = json_decode($detalleJson, true);
if (!$detalle) {
    echo json_encode(["status" => "error", "message" => "Detalle inválido"]);
    exit;
}

$mysqli->begin_transaction();

try {
    // Insertar venta
    $stmtVenta = $mysqli->prepare("INSERT INTO Ventas (ClienteID, FechaVenta, Total) VALUES (?, ?, ?)");
    $stmtVenta->bind_param("isd", $clienteID, $fechaVenta, $total);
    $stmtVenta->execute();
    $ventaID = $stmtVenta->insert_id;
    $stmtVenta->close();

    // Preparar statement para detalle
    $stmtDetalle = $mysqli->prepare("INSERT INTO DetalleVenta (VentaID, ProductoID, Cantidad, PrecioUnitario) VALUES (?, ?, ?, ?)");

    // Preparar statement para actualizar stock
    $stmtStock = $mysqli->prepare("UPDATE Productos SET Stock = Stock - ? WHERE ProductoID = ?");

    foreach ($detalle as $item) {
        $productoID     = intval($item['ProductoID']);
        $cantidad       = intval($item['Cantidad']);
        $precioUnitario = floatval($item['PrecioUnitario']);

        // Insertar detalle
        $stmtDetalle->bind_param("iiid", $ventaID, $productoID, $cantidad, $precioUnitario);
        $stmtDetalle->execute();

        // Actualizar stock
        $stmtStock->bind_param("ii", $cantidad, $productoID);
        $stmtStock->execute();
    }

    $stmtDetalle->close();
    $stmtStock->close();

    $mysqli->commit();

    echo json_encode([
        "status"  => "ok",
        "ventaID" => $ventaID,
        "message" => "Venta guardada y stock actualizado correctamente"
    ]);
} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode([
        "status"  => "error",
        "message" => $e->getMessage()
    ]);
}

$mysqli->close();




?>