<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php";

// Opcional: unir con usuarios para traer el nombre del alumno
// Si no lo necesitás, podés usar el SELECT simple sin JOIN
/*
$sql = "SELECT r.id_rutina, r.nombre, r.id, u.nombre  AS alumno
        FROM rutinas r
        LEFT JOIN usuarios u ON r.id = u.id
        ORDER BY r.id_rutina DESC";
*/

$sql = "SELECT r.id_rutina, r.nombre, r.id, u.nombre AS alumno
FROM rutinas r
LEFT JOIN usuarios u ON r.id = u.id
ORDER BY u.apellido ASC, u.nombre ASC;";


$result = $mysqli->query($sql);

if (!$result) {
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => "Error en la consulta: " . $mysqli->error
    ], JSON_UNESCAPED_UNICODE);
    $mysqli->close();
    exit;
}

$rutinas = [];
while ($row = $result->fetch_assoc()) {
    // Mantener exactamente estos nombres de campos para tu parser con Regex
    $rutinas[] = [
        "id_rutina" => (int)$row["id_rutina"],
        "nombre"    => $row["nombre"],
        "id"        => (int)$row["id"],        // FK a usuarios.id
        // Campo extra por si querés mostrar el nombre del alumno (no rompe tu parser)
        "alumno"    => isset($row["alumno"]) ? $row["alumno"] : null
    ];
}

echo json_encode($rutinas, JSON_UNESCAPED_UNICODE);

$mysqli->close();