<?php
header("Content-Type: application/json");
require_once "conexion.php";

$dni = $_GET['dni'];

// Buscar el usuario por DNI
//$sql = "SELECT id, nombre, apellido  FROM usuarios WHERE dni = ?";
$sql = "SELECT id, nombre, apellido AS apellido FROM usuarios WHERE dni = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $dni);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    // Devuelve {"id":3,"nombre":"Juan"}
    echo json_encode($row);
} else {
    // Si no existe, devuelve objeto vacío
    echo json_encode([]);
}

$stmt->close();
$mysqli->close();
?>