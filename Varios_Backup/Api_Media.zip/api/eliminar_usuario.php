<?php
header('Content-Type: application/json');
include 'conexion.php'; // Debe definir $conexion como mysqli

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Preparar la consulta para evitar inyecciones SQL
    $stmt = $mysqli->prepare("DELETE FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["ok success" => "Usuario eliminado correctamente"]);
    } else {
        echo json_encode(["error" => $stmt->error]);
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode(["error" => "No se indicó el ID del usuario"]);
}
?>
