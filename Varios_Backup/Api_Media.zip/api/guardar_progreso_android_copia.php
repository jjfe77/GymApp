<?php
header("Content-Type: application/json");
require_once "conexion.php";

$idAlumno = intval($_POST['id_alumno']);
$idRutina = intval($_POST['id_rutina']);
$idRutinaEjercicio = intval($_POST['id_rutina_ejercicio']);
$seriesReal = intval($_POST['series_real']);
$repReal = intval($_POST['repeticiones_real']);
$cargaReal = intval($_POST['carga_real']);

$sql = "INSERT INTO ejercicios_realizados
        (id_alumno, id_rutina, id_rutina_ejercicio, series_real, repeticiones_real, carga_real, fecha)
        VALUES (?, ?, ?, ?, ?, ?, CURDATE())";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("iiiiii",
                  $idAlumno, $idRutina, $idRutinaEjercicio,
                  $seriesReal, $repReal, $cargaReal);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>

