<?php
header('Content-Type: application/json');
include 'conexion.php';

$id_usuario = $_POST['id_usuario'] ?? '';
$ultima_fecha_pago = $_POST['ultima_fecha_pago'] ?? '';
$fecha_vencimiento = $_POST['fecha_vencimiento'] ?? '';
$tipo_membresia = $_POST['tipo_membresia'] ?? '';
$importe = $_POST['importe'] ?? '';

if ($id_usuario === '') {
    echo json_encode(["error" => "Falta id_usuario"]);
    exit;
}

// Respaldo: calcular estado en PHP
$hoy = date('Y-m-d');
$estado = ($fecha_vencimiento < $hoy) ? "Vencida" : "Activa";

$sql = "UPDATE cuotas SET
        ultima_fecha_pago = '$ultima_fecha_pago',
        fecha_vencimiento = '$fecha_vencimiento',
        tipo_membresia = '$tipo_membresia',
        importe = '$importe',
        estado = '$estado'
        WHERE id_usuario = '$id_usuario'";

if ($mysqli->query($sql)) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["error" => $mysqli->error]);
}
