<?php
header('Content-Type: application/json');
include 'conexion.php';

$id          = $_POST['ProductoID'] ?? '';
$nombre      = $_POST['Nombre'] ?? '';
$descripcion = $_POST['Descripcion'] ?? '';
$precio      = $_POST['Precio'] ?? '';
$stock       = $_POST['Stock'] ?? '';
//$categoria   = $_POST['Categoria'] ?? '';

if ($id === '' || $nombre === '' || $descripcion === '' || $precio === '' || $stock === '' ) {
    echo json_encode(["error" => "Faltan datos obligatorios"]);
    exit;
}

$stmt = $mysqli->prepare(
    "UPDATE Productos 
     SET Nombre = ?, Descripcion = ?, Precio = ?, Stock = ?
     WHERE ProductoID = ?"
);

if ($stmt === false) {
    echo json_encode(["error" => $mysqli->error]);
    exit;
}

// Precio decimal, Stock y Categoria enteros, ID entero
$stmt->bind_param("ssdii", $nombre, $descripcion, $precio, $stock,  $id);

if ($stmt->execute()) {
    echo json_encode(["success" => "Producto actualizado correctamente"]);
} else {
    echo json_encode(["error" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>