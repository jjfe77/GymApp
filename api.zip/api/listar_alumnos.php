<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php"; // tu archivo de conexión a MySQL

// Concatenamos nombre + apellido en la consulta
//$sql = "SELECT id, CONCAT(nombre, ' ', apellido) AS nombre_completo
$sql = "SELECT id, CONCAT(apellido, ' ', nombre) AS nombre_completo
        FROM usuarios
        WHERE rol = 'Alumno'
        ORDER BY apellido";
        //ORDER BY id";

$result = $mysqli->query($sql);

$alumnos = [];
while ($row = $result->fetch_assoc()) {
    $alumnos[] = [
        "id" => (int)$row["id"],
        "nombre" => $row["nombre_completo"]
    ];
}

echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);

$mysqli->close();
?>