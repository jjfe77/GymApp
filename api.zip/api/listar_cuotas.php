<?php
header("Content-Type: application/json");
require_once "conexion.php";

$sql = "
SELECT 
    c.id_usuario AS id_usuario,
    u.dni AS dni,
    u.nombre AS nombre,
    u.apellido AS apellido,
    c.fecha_inscripcion,
    c.ultima_fecha_pago,
    c.fecha_vencimiento,
    c.tipo_membresia,
    c.estado
FROM cuotas c
INNER JOIN usuarios u ON c.id_usuario = u.id
ORDER BY u.apellido, u.nombre;
";

$result = $mysqli->query($sql);

$datos = [];

if ($result) {
    while ($fila = $result->fetch_assoc()) {
        // Convertir NULL → "" y todo a string
        foreach ($fila as $k => $v) {
            if (is_null($v)) $fila[$k] = "";
            else $fila[$k] = (string)$v;
        }
        $datos[] = $fila;
    }
}

echo json_encode($datos, JSON_UNESCAPED_UNICODE);
