<?php
header("Content-Type: application/json");
require_once "conexion.php";

$idRutina = intval($_GET['id_rutina']);

$sql = "SELECT re.id_rutina_ejercicio,
               e.nombre AS ejercicio,
               re.series,
               re.repeticiones,
               re.carga
        FROM rutina_ejercicios re
        INNER JOIN ejercicios e ON re.id_ejercicio = e.id_ejercicio
        WHERE re.id_rutina = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $idRutina);
$stmt->execute();
$result = $stmt->get_result();

$ejercicios = [];
while ($row = $result->fetch_assoc()) {
    $ejercicios[] = [
        "id_rutina_ejercicio" => intval($row["id_rutina_ejercicio"]),
        "ejercicio" => $row["ejercicio"],
        "series" => intval($row["series"]),
        "repeticiones" => intval($row["repeticiones"]),
        "carga" => floatval($row["carga"])
    ];
}

echo json_encode($ejercicios, JSON_UNESCAPED_UNICODE);

$stmt->close();
$mysqli->close();
?>
