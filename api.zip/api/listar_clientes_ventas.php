<?php
header('Content-Type: application/json');
include 'conexion.php';

$sql = "SELECT ClienteID, CONCAT(apellido, ' ', nombre) AS NombreCompleto 
        FROM Clientes 
        ORDER BY apellido ASC, nombre ASC";

$result = $mysqli->query($sql);

$clientes = array();
while ($row = $result->fetch_assoc()) {
    $clientes[] = array(
        "ClienteID" => strval($row["ClienteID"]),
        "NombreCompleto" => $row["NombreCompleto"]
    );
}

echo json_encode($clientes);

$mysqli->close();
?>