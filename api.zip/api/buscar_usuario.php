<?php
include 'conexion.php';

if(isset($_GET['apellido'])) {
    $apellido = $_GET['apellido'];
    $stmt = $mysqli->prepare("SELECT * FROM usuarios WHERE apellido LIKE CONCAT('%', ?, '%')");
    $stmt->bind_param("s", $apellido);
    $stmt->execute();
    $result = $stmt->get_result();

    $rows = [];
    while($row = $result->fetch_assoc()) {
        // concatenar columnas separadas por '|'
        $rows[] = implode("|", [
            $row['id'], $row['dni'], $row['nombre'], $row['apellido'], $row['rol'],
            $row['edad'], $row['peso'], $row['altura'], $row['grupo_sanguineo'],
            $row['direccion'], $row['telefono']
        ]);
    }
    echo implode(";", $rows); // filas separadas por ';'
}
?>
