<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php";

$response = [];

$sql = "SELECT id_equipo, nombre FROM equipos ORDER BY nombre ASC";
$result = $mysqli->query($sql);

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $response[] = [
            "id_equipo" => (int)$row["id_equipo"],
            "nombre" => $row["nombre"]
        ];
    }
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$mysqli->close();
?>