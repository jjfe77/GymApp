<?php
header('Content-Type: application/json');
include 'conexion.php';

$sql = "SELECT ProductoID, Nombre, Descripcion, Precio, Stock
        FROM Productos 
        ORDER BY Nombre ASC";

$result = $mysqli->query($sql);

$productos = array();
while ($row = $result->fetch_assoc()) {
    // Convertimos todo a string para que tu regex lo capture sin problemas
    $productos[] = array(
        "ProductoID"  => strval($row["ProductoID"]),
        "Nombre"      => strval($row["Nombre"]),
        "Descripcion" => strval($row["Descripcion"]),
        "Precio"      => strval($row["Precio"]),
        "Stock"       => strval($row["Stock"])
    );
}

echo json_encode($productos);

$mysqli->close();
?>