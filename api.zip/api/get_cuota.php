<?php
header('Content-Type: application/json');
include 'conexion.php';

$id_usuario = $_GET['id_usuario'] ?? '';

if ($id_usuario === '') {
    echo json_encode(["error" => "Falta id_usuario"]);
    exit;
}

$sql = "SELECT * FROM cuotas WHERE id_usuario = $id_usuario LIMIT 1";
$res = $mysqli->query($sql);

if ($res->num_rows > 0) {
    echo json_encode($res->fetch_assoc(), JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([]);
}
