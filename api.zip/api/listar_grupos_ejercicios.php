<?php
header("Content-Type: application/json");
require_once "conexion.php";

$sql = "SELECT id_grupo, nombre FROM GrupoMuscular ORDER BY nombre";
$result = $mysqli->query($sql);

$grupos = [];
while ($row = $result->fetch_assoc()) {
    $grupos[] = $row;
}
echo json_encode($grupos);

$mysqli->close();
?>