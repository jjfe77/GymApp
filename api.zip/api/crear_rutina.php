<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php";

// Recibir parámetros
$nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
$id     = isset($_POST['id']) ? intval($_POST['id']) : 0;

// Validación
if ($nombre === '' || $id <= 0) {
    echo json_encode([
        "status"  => "error",
        "message" => "Datos incompletos: nombre o id inválido",
        "debug"   => $_POST
    ]);
    exit;
}

// Insertar rutina
$sql = "INSERT INTO rutinas (nombre, id) VALUES (?, ?)";
$stmt = $mysqli->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "status"  => "error",
        "message" => "Error en prepare: " . $mysqli->error
    ]);
    exit;
}

$stmt->bind_param("si", $nombre, $id);

if ($stmt->execute()) {
    echo json_encode([
        "status"    => "success",
        "message"   => "Rutina creada correctamente",
        "id_rutina" => $stmt->insert_id,
        "debug"     => ["nombre"=>$nombre, "id"=>$id]
    ]);
} else {
    echo json_encode([
        "status"  => "error",
        "message" => "Error en execute: " . $stmt->error
    ]);
}

$stmt->close();
$mysqli->close();
?>