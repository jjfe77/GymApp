<?php
header('Content-Type: application/json');
include 'conexion.php'; // tu conexión centralizada

$sql = "SELECT ClienteID, Nombre, Apellido, Contacto 
        FROM Clientes 
        ORDER BY Apellido ASC, Nombre ASC";

$result = $mysqli->query($sql);

$clientes = array();
while ($row = $result->fetch_assoc()) {
    $clientes[] = $row;
}

echo json_encode($clientes);

$mysqli->close();
?>