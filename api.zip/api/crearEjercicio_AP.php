<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php"; // usa $mysqli

$response = ["success" => false, "message" => "", "id_ejercicio" => null];

try {
    // Leer y validar JSON
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    if (!$data) {
        throw new Exception("JSON inválido o vacío.");
    }

    $nombre      = trim($data["nombre"] ?? "");
    $id_grupo    = $data["id_grupo"] ?? null;
    $descripcion = isset($data["descripcion"]) ? trim($data["descripcion"]) : null;
    $id_equipo   = $data["id_equipo"] ?? null;

    if ($nombre === "" || !$id_grupo || !$id_equipo) {
        throw new Exception("Faltan datos obligatorios: nombre, id_grupo o id_equipo.");
    }

    // Insertar ejercicio directamente con id_equipo
    $stmt = $mysqli->prepare("INSERT INTO ejercicios (nombre, id_grupo, descripcion, id_equipo) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception("Error al preparar inserción en ejercicios: " . $mysqli->error);
    }
    // s i s i (string, int, string|nullable, int)
    $stmt->bind_param("sisi", $nombre, $id_grupo, $descripcion, $id_equipo);
    if (!$stmt->execute()) {
        throw new Exception("Error al insertar ejercicio: " . $stmt->error);
    }
    $id_ejercicio = $stmt->insert_id;
    $stmt->close();

    $response["success"] = true;
    $response["message"] = "Ejercicio creado correctamente.";
    $response["id_ejercicio"] = $id_ejercicio;

} catch (Exception $e) {
    $response["success"] = false;
    $response["message"] = $e->getMessage();
} finally {
    if ($mysqli instanceof mysqli) {
        $mysqli->close();
    }
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>