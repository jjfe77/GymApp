<?php
header("Content-Type: application/json");
require_once "conexion.php";

$id_equipo = isset($_POST['id_equipo']) ? intval($_POST['id_equipo']) : 0;

if ($id_equipo <= 0) {
    echo json_encode(["error" => "ID de equipo inválido"]);
    exit;
}

$stmt = $mysqli->prepare("DELETE FROM equipos WHERE id_equipo=?");
$stmt->bind_param("i", $id_equipo);

if ($stmt->execute()) {
    echo json_encode(["success" => "Equipo eliminado correctamente"]);
} else {
    echo json_encode(["error" => "Error al eliminar: " . $mysqli->error]);
}

$stmt->close();
$mysqli->close();
?>