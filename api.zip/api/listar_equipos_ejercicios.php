<?php
header("Content-Type: application/json");
require_once "conexion.php";

$sql = "SELECT id_equipo, nombre FROM Equipos ORDER BY nombre";
$result = $mysqli->query($sql);

$equipos = [];
while ($row = $result->fetch_assoc()) {
    $equipos[] = $row;
}
echo json_encode($equipos);

$mysqli->close();
?>