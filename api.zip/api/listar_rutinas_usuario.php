<?php
header("Content-Type: application/json");
require_once "conexion.php";

$idAlumno = intval($_GET['id']); // viene desde el botón Buscar

$sql = "SELECT id_rutina, nombre 
        FROM rutinas 
        WHERE id = ?";   // solo rutinas de ese alumno

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $idAlumno);
$stmt->execute();
$result = $stmt->get_result();

$rutinas = [];
while ($row = $result->fetch_assoc()) {
    $rutinas[] = $row;
}

echo json_encode($rutinas);

$stmt->close();
$mysqli->close();
?>