<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php";

$id = isset($_GET['id_rutina_ejercicio']) ? intval($_GET['id_rutina_ejercicio']) : 0;

if ($id <= 0) {
    echo json_encode(["status" => "error", "msg" => "ID inválido"]);
    exit();
}

$sql = "DELETE FROM rutina_ejercicios WHERE id_rutina_ejercicio = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(["status" => "ok", "msg" => "Ejercicio eliminado"]);
} else {
    echo json_encode(["status" => "error", "msg" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>