<?php
header("Content-Type: application/json");
require_once "conexion.php";

$idAlumno = intval($_GET['id']);

$sql = "SELECT id_rutina, nombre
        FROM rutinas
        WHERE id = ?";  // este id es el id_usuario del alumno

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $idAlumno);
$stmt->execute();
$result = $stmt->get_result();

$rutinas = [];
while ($row = $result->fetch_assoc()) {
    $rutinas[] = [
        "id_rutina" => intval($row["id_rutina"]),
        "nombre" => $row["nombre"]
    ];
}

echo json_encode($rutinas, JSON_UNESCAPED_UNICODE);

$stmt->close();
$mysqli->close();
?>
